# Lead Scraper Bot (Version 1.1.0)

An AI-assisted lead scraping utility for Windows PowerShell that combines Google Maps data, lightweight website scraping, and optional OpenAI analysis. The project ships with a modern WPF GUI so that non-technical teammates can start gathering leads within minutes, while still supporting scripted CLI execution for automation scenarios.

> **Important**
> *You must supply your own Google Maps API key (Places + Geocoding enabled). You may also supply an OpenAI API key to enable AI analysis. Without an OpenAI key the scraper still runs, it simply omits AI insights.*

## Quick Start (Under 2 Minutes)

1. **Install prerequisites**
   - Windows PowerShell 5.1 (or PowerShell 7+)
   - .NET Desktop Runtime (already included with Windows 10+)
   - Internet access.

2. **Clone or download** this repository and open the folder in File Explorer.

3. **Double-click `LeadScraper.ps1`** (or right-click ➜ “Run with PowerShell”). If execution policies block the script, run PowerShell as Administrator once and execute:

   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
   ```

4. The GUI will appear. Fill in the form:
   - **Location** – e.g., `Austin, TX`
   - **Radius (miles)** – e.g., `10`
   - **Service offered** – what you sell (used by the AI prompt)
   - **Google API Key** – required
   - **OpenAI API Key** – optional; leave blank to skip AI
   - Optionally add keyword, Google place type, choose CSV/JSON output, select destination folder, and enable the map overlay.

5. Click **Run**. Progress is shown inside the window. When finished a message box reports the saved file path and lets you open the folder immediately. If you enabled mapping, the browser opens an interactive HTML map with the leads.

That’s it – you now have a timestamped CSV/JSON with detailed lead information and (optionally) AI-enriched insights.

## Features

- 🚀 **Modern WPF GUI** with validation, progress feedback, and friendly completion prompts.
- 🌐 **Google Places & Geocoding** integration with robust retry logic to survive transient network hiccups.
- 🔎 **Smart website scraping** for contact emails, owner names, and metadata.
- 🤖 **Optional OpenAI analysis** that highlights key benefits, pain points, and a 1–10 likelihood score for your service.
- 🗺️ **Interactive HTML map** overlaying all located leads inside the selected radius.
- 🧱 **Modular architecture** (PowerShell module + manifest + entry script) ready for future enhancements.
- ✅ **Automated tests** (`tests/RunTests.ps1`) covering critical helper functions.

## Directory Layout

```
LeadScraper.ps1           # Entry point (GUI + CLI support)
src/LeadScraper.psm1      # Core module with scraping & AI logic
src/LeadScraper.psd1      # Module manifest
tests/RunTests.ps1        # Pester-style tests for utilities
```

## Configuration Notes

- **Rate Limits:** The module throttles OpenAI calls (default 1.2 s delay) to remain within free-tier limits. Adjust the `-OpenAIDelayMilliseconds` parameter if needed.
- **Result Files:** Output files follow the pattern `leads_<Location>_<Radius>mi_<Service>_<Timestamp>.csv|json` and are saved to your chosen directory.
- **API Keys:** For convenience you can set environment variables `GOOGLE_MAPS_API_KEY` and `OPENAI_API_KEY`. The GUI honors direct input first, then falls back to environment variables in CLI mode.

## Testing

Run the automated tests from PowerShell:

```powershell
Set-Location <repo-root>
pwsh -NoLogo -File tests/RunTests.ps1
```

The harness exercises critical helper functions, validates prompt construction, and uses lightweight mocks to simulate end-to-end scraping (including map output) without requiring live API keys. For maximum confidence, run the script multiple times in succession (the repo maintainers execute it ten times back-to-back before shipping) to verify deterministic behaviour.

## Troubleshooting

- **Authentication Errors:** Double-check that your Google key has both Places API and Geocoding API enabled. Verify billing is active (Google’s free tier still requires a billing account).
- **OpenAI Errors:** If the AI call fails, the script logs a warning and continues. Check your key, model availability, and rate limits.
- **Map Loading Issues:** Ensure the same Google API key allows usage of the Maps JavaScript API. The HTML file is generated in your output directory.

## License

MIT License. See `LICENSE` for details.

