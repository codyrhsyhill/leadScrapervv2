<#
.SYNOPSIS
    Entry point for the Lead Scraper Bot.
.DESCRIPTION
    Launches the WPF GUI when invoked without parameters, or executes in
    command-line mode when arguments are provided. The heavy lifting is
    delegated to the LeadScraper PowerShell module located in ./src.
#>
[CmdletBinding()]
param(
    [string]$Location,
    [double]$RadiusMiles = 10,
    [string]$Service = 'Facebook Ads marketing and analytics',
    [string]$Keyword,
    [string]$Type,
    [string]$OutputDirectory,
    [ValidateSet('csv','json')][string]$OutputFormat = 'csv',
    [string]$GoogleApiKey,
    [string]$OpenAIApiKey,
    [string]$OpenAIModel = 'gpt-3.5-turbo',
    [switch]$SkipAI,
    [switch]$ShowMap
)

$PSScriptRoot = Split-Path -Parent $PSCommandPath
Import-Module -Force -Name (Join-Path $PSScriptRoot 'src' 'LeadScraper.psd1')

if ($PSBoundParameters.Count -eq 0) {
    Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
    Add-Type -AssemblyName System.Windows.Forms

    $xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Lead Scraper Bot" Height="520" Width="440"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize">
    <Grid Margin="10">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
        </Grid.RowDefinitions>
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto" />
            <ColumnDefinition Width="*" />
            <ColumnDefinition Width="Auto" />
        </Grid.ColumnDefinitions>

        <TextBlock Grid.ColumnSpan="3" Text="Lead Scraper Bot" FontSize="20"
                   FontWeight="Bold" Margin="0 0 0 12"/>

        <TextBlock Grid.Row="1" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Location:</TextBlock>
        <TextBox x:Name="LocationBox" Grid.Row="1" Grid.Column="1" MinWidth="220" Margin="0 5 0 5" />

        <TextBlock Grid.Row="2" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Radius (miles):</TextBlock>
        <TextBox x:Name="RadiusBox" Grid.Row="2" Grid.Column="1" Margin="0 5 0 5" Text="10"/>

        <TextBlock Grid.Row="3" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Service offered:</TextBlock>
        <TextBox x:Name="ServiceBox" Grid.Row="3" Grid.Column="1" Margin="0 5 0 5" Text="Facebook Ads marketing and analytics"/>

        <TextBlock Grid.Row="4" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Business keyword:</TextBlock>
        <TextBox x:Name="KeywordBox" Grid.Row="4" Grid.Column="1" Margin="0 5 0 5" ToolTip="Optional keyword filter"/>

        <TextBlock Grid.Row="5" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Business type:</TextBlock>
        <TextBox x:Name="TypeBox" Grid.Row="5" Grid.Column="1" Margin="0 5 0 5" ToolTip="Optional Google place type"/>

        <TextBlock Grid.Row="6" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Google API Key:</TextBlock>
        <PasswordBox x:Name="GoogleKeyBox" Grid.Row="6" Grid.Column="1" Margin="0 5 0 5"/>

        <TextBlock Grid.Row="7" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">OpenAI API Key:</TextBlock>
        <PasswordBox x:Name="OpenAIKeyBox" Grid.Row="7" Grid.Column="1" Margin="0 5 0 5" ToolTip="Optional"/>

        <TextBlock Grid.Row="8" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Output format:</TextBlock>
        <ComboBox x:Name="FormatBox" Grid.Row="8" Grid.Column="1" Margin="0 5 0 5" SelectedIndex="0">
            <ComboBoxItem>csv</ComboBoxItem>
            <ComboBoxItem>json</ComboBoxItem>
        </ComboBox>

        <TextBlock Grid.Row="9" Grid.Column="0" Margin="0 5 8 5" VerticalAlignment="Center">Output folder:</TextBlock>
        <TextBox x:Name="OutputDirBox" Grid.Row="9" Grid.Column="1" Margin="0 5 0 5"/>
        <Button x:Name="BrowseBtn" Grid.Row="9" Grid.Column="2" Margin="6 5 0 5" Content="Browse..." Padding="8,2"/>

        <CheckBox x:Name="ShowMapBox" Grid.Row="10" Grid.Column="1" Margin="0 5 0 5" Content="Show map after scraping"/>

        <Button x:Name="RunBtn" Grid.Row="11" Grid.Column="1" Content="Run" Padding="18,6"
                Margin="0 18 0 0" HorizontalAlignment="Center" Background="#FF007ACC" Foreground="White" FontWeight="Bold"/>

        <ProgressBar x:Name="ProgressBar" Grid.Row="12" Grid.ColumnSpan="3" Height="16" Margin="0 12 0 0" Visibility="Collapsed"/>
        <TextBlock x:Name="StatusText" Grid.Row="13" Grid.ColumnSpan="3" Foreground="Green" FontWeight="Bold" TextAlignment="Center"/>
    </Grid>
</Window>
"@

    $reader = New-Object System.Xml.XmlNodeReader $xaml
    try {
        $window = [Windows.Markup.XamlReader]::Load($reader)
    }
    catch {
        Write-Error "Failed to load GUI: $($_.Exception.Message)"
        return
    }

    $LocationBox  = $window.FindName('LocationBox')
    $RadiusBox    = $window.FindName('RadiusBox')
    $ServiceBox   = $window.FindName('ServiceBox')
    $KeywordBox   = $window.FindName('KeywordBox')
    $TypeBox      = $window.FindName('TypeBox')
    $GoogleKeyBox = $window.FindName('GoogleKeyBox')
    $OpenAIKeyBox = $window.FindName('OpenAIKeyBox')
    $FormatBox    = $window.FindName('FormatBox')
    $OutputDirBox = $window.FindName('OutputDirBox')
    $BrowseBtn    = $window.FindName('BrowseBtn')
    $ShowMapBox   = $window.FindName('ShowMapBox')
    $RunBtn       = $window.FindName('RunBtn')
    $ProgressBar  = $window.FindName('ProgressBar')
    $StatusText   = $window.FindName('StatusText')

    try { $OutputDirBox.Text = (Get-Location).Path } catch { $OutputDirBox.Text = '' }

    $BrowseBtn.Add_Click({
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Select output folder'
        $dialog.ShowNewFolderButton = $true
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $OutputDirBox.Text = $dialog.SelectedPath
        }
    })

    $RunBtn.Add_Click({
        if ([string]::IsNullOrWhiteSpace($LocationBox.Text)) {
            [System.Windows.MessageBox]::Show('Please enter a location.', 'Input Required', 'OK', 'Warning') | Out-Null
            return
        }
        if ([string]::IsNullOrWhiteSpace($GoogleKeyBox.Password)) {
            [System.Windows.MessageBox]::Show('Google API Key is required.', 'Input Required', 'OK', 'Warning') | Out-Null
            return
        }
        $radiusVal = 0.0
        if (-not [double]::TryParse($RadiusBox.Text, [ref]$radiusVal) -or $radiusVal -le 0) {
            [System.Windows.MessageBox]::Show('Radius must be a positive number.', 'Input Error', 'OK', 'Error') | Out-Null
            return
        }

        $RunBtn.IsEnabled = $false
        $BrowseBtn.IsEnabled = $false
        $StatusText.Text = ''
        $ProgressBar.IsIndeterminate = $true
        $ProgressBar.Visibility = 'Visible'
        $window.Cursor = [System.Windows.Input.Cursors]::Wait

        $params = @{
            Location     = $LocationBox.Text
            RadiusMiles  = $radiusVal
            Service      = $ServiceBox.Text
            Keyword      = $KeywordBox.Text
            Type         = $TypeBox.Text
            OutputFormat = $FormatBox.Text
            GoogleApiKey = $GoogleKeyBox.Password
            OpenAIApiKey = $OpenAIKeyBox.Password
            OpenAIModel  = $OpenAIModel
        }
        if ($OutputDirBox.Text) { $params.OutputDirectory = $OutputDirBox.Text }
        if ([string]::IsNullOrWhiteSpace($OpenAIKeyBox.Password)) { $params.SkipAI = $true }
        if ($ShowMapBox.IsChecked) { $params.ShowMap = $true }

        try {
            $result = Invoke-LeadScraper @params
        }
        catch {
            [System.Windows.MessageBox]::Show("An error occurred: $($_.Exception.Message)", 'Error', 'OK', 'Error') | Out-Null
            $window.Cursor = [System.Windows.Input.Cursors]::Arrow
            $ProgressBar.Visibility = 'Collapsed'
            $RunBtn.IsEnabled = $true
            $BrowseBtn.IsEnabled = $true
            return
        }

        $window.Cursor = [System.Windows.Input.Cursors]::Arrow
        $ProgressBar.IsIndeterminate = $false
        $ProgressBar.Visibility = 'Collapsed'
        $RunBtn.IsEnabled = $true
        $BrowseBtn.IsEnabled = $true

        if (-not $result -or -not $result.Leads -or $result.Leads.Count -eq 0) {
            $StatusText.Foreground = 'OrangeRed'
            $StatusText.Text = 'No leads found for the specified criteria.'
            return
        }

        $filePath = $result.OutputPath
        $outDir = if ($OutputDirBox.Text) { $OutputDirBox.Text } else { (Get-Location).Path }
        if (-not $filePath) {
            $filePath = Join-Path $outDir 'leads_output.csv'
        }

        $StatusText.Foreground = 'Green'
        $StatusText.Text = "Completed! Saved to $filePath"
        $result = [System.Windows.MessageBox]::Show("Lead scraping completed.`nResults saved to:`n$filePath`n`nOpen the output folder now?", 'Scraping Finished', 'YesNo', 'Information')
        if ($result -eq 'Yes') {
            try { Invoke-Item $outDir } catch { }
        }
    })

    $window.ShowDialog() | Out-Null
    return
}

try {
    $params = @{
        Location     = $Location
        RadiusMiles  = $RadiusMiles
        Service      = $Service
        Keyword      = $Keyword
        Type         = $Type
        OutputFormat = $OutputFormat
        GoogleApiKey = $GoogleApiKey
        OpenAIApiKey = $OpenAIApiKey
        OpenAIModel  = $OpenAIModel
    }
    if ($PSBoundParameters.ContainsKey('OutputDirectory')) { $params.OutputDirectory = $OutputDirectory }
    if ($SkipAI) { $params.SkipAI = $true }
    if ($ShowMap) { $params.ShowMap = $true }

    if (-not $params.Location) {
        $params.Location = Read-Host 'Enter a target location (address, city, or postcode)'
    }

    $result = Invoke-LeadScraper @params

    if (-not $params.ContainsKey('OutputDirectory')) {
        $params.OutputDirectory = (Get-Location).Path
    }

    $filePath = if ($result) { $result.OutputPath } else { $null }
    if (-not $filePath) {
        $filePath = Join-Path $params.OutputDirectory 'leads_output.csv'
    }

    Write-Host "Saved lead data to $filePath" -ForegroundColor Green
    if ($result -and $result.MapPath) {
        Write-Host "Map saved to $($result.MapPath)" -ForegroundColor Green
    }
}
catch {
    Write-Error "Error: $($_.Exception.Message)"
}
