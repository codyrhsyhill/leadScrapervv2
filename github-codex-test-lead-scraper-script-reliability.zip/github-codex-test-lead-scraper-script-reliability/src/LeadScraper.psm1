Set-StrictMode -Version Latest

function ConvertTo-Meters {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][double]$Value,
        [ValidateSet('mile','kilometer')][string]$Unit = 'mile'
    )

    switch ($Unit) {
        'mile'      { return [math]::Round($Value * 1609.344, 2) }
        'kilometer' { return [math]::Round($Value * 1000, 2) }
        default     { throw "Unsupported unit '$Unit'." }
    }
}

function Normalize-FileNameComponent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Text
    )

    if ([string]::IsNullOrWhiteSpace($Text)) { return 'value' }
    $sanitized = $Text.Trim()
    $sanitized = $sanitized -replace '\s+', '_'
    $sanitized = $sanitized -replace '[^\w\-]+', ''
    if ([string]::IsNullOrEmpty($sanitized)) { return 'value' }
    return $sanitized
}

function New-LeadOutputFileName {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Location,
        [Parameter(Mandatory)][double]$RadiusMiles,
        [Parameter(Mandatory)][string]$Service,
        [ValidateSet('csv','json')][string]$Format = 'csv',
        [DateTime]$Timestamp = [DateTime]::UtcNow
    )

    $locComponent = Normalize-FileNameComponent -Text $Location
    $serviceComponent = Normalize-FileNameComponent -Text $Service
    $timeComponent = $Timestamp.ToString('yyyyMMdd_HHmmss')
    $extension = if ($Format -eq 'json') { 'json' } else { 'csv' }
    return "leads_${locComponent}_${RadiusMiles}mi_${serviceComponent}_${timeComponent}.${extension}"
}

function Invoke-RestMethodWithRetry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [string]$Method = 'GET',
        [hashtable]$Headers,
        $Body,
        [int]$MaxAttempts = 3,
        [int]$InitialDelaySeconds = 2,
        [int]$MaxDelaySeconds = 8
    )

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            return Invoke-RestMethod -Uri $Uri -Method $Method -Headers $Headers -Body $Body -TimeoutSec 30 -ErrorAction Stop
        }
        catch {
            Write-Warning ("Request to {0} failed on attempt {1}: {2}" -f $Uri, $attempt, $_.Exception.Message)
            if ($attempt -eq $MaxAttempts) { throw }
            $delay = [math]::Min($InitialDelaySeconds * $attempt, $MaxDelaySeconds)
            Start-Sleep -Seconds $delay
        }
    }
}

function Get-Geocode {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Location,
        [Parameter(Mandatory)][string]$ApiKey
    )

    $encodedLocation = [System.Net.WebUtility]::UrlEncode($Location)
    $uri = "https://maps.googleapis.com/maps/api/geocode/json?address=$encodedLocation&key=$ApiKey"
    $response = Invoke-RestMethodWithRetry -Uri $uri
    if ($response.status -ne 'OK' -or -not $response.results) {
        throw "Geocoding API failure: $($response.status) – Unable to geocode '$Location'."
    }

    $result = $response.results[0]
    [PSCustomObject]@{
        Latitude         = $result.geometry.location.lat
        Longitude        = $result.geometry.location.lng
        FormattedAddress = $result.formatted_address
    }
}

function Get-PlacesNearby {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][double]$Latitude,
        [Parameter(Mandatory)][double]$Longitude,
        [Parameter(Mandatory)][int]$RadiusMeters,
        [Parameter(Mandatory)][string]$ApiKey,
        [string]$Keyword,
        [string]$Type,
        [int]$MaxResults = 120,
        [int]$DelaySeconds = 2
    )

    $uriBase = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$Latitude,$Longitude&radius=$RadiusMeters&key=$ApiKey"
    if ($Keyword) { $uriBase += "&keyword=$([System.Net.WebUtility]::UrlEncode($Keyword))" }
    if ($Type)    { $uriBase += "&type=$([System.Net.WebUtility]::UrlEncode($Type))" }

    $places = @()
    $nextPageToken = $null
    do {
        $uri = if ($nextPageToken) {
            Start-Sleep -Seconds $DelaySeconds
            "https://maps.googleapis.com/maps/api/place/nearbysearch/json?pagetoken=$nextPageToken&key=$ApiKey"
        } else {
            $uriBase
        }

        $resp = Invoke-RestMethodWithRetry -Uri $uri
        if ($resp.status -notin @('OK','ZERO_RESULTS')) {
            throw "Places API error: $($resp.status) – Unable to search for places."
        }
        if ($resp.results) { $places += $resp.results }
        $nextPageToken = $resp.next_page_token
    } while ($nextPageToken -and $places.Count -lt $MaxResults)

    if ($places.Count -gt $MaxResults) {
        $places = $places[0..($MaxResults-1)]
    }
    return $places
}

function Get-PlaceDetails {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$PlaceId,
        [Parameter(Mandatory)][string]$ApiKey
    )

    $fields = 'name,formatted_address,international_phone_number,website,rating,user_ratings_total,geometry,address_component,url'
    $uri = "https://maps.googleapis.com/maps/api/place/details/json?place_id=$PlaceId&fields=$fields&key=$ApiKey"
    $resp = Invoke-RestMethodWithRetry -Uri $uri
    if ($resp.status -ne 'OK') {
        throw "Place Details API error: $($resp.status) – Unable to get details for PlaceId $PlaceId."
    }
    return $resp.result
}

function Get-NormalizedUri {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Url
    )

    try {
        if ([string]::IsNullOrWhiteSpace($Url)) { return $null }
        return [Uri]::new($Url)
    }
    catch {
        return $null
    }
}

function Get-WebsiteContent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][Uri]$Uri,
        [Parameter(Mandatory)][System.Net.Http.HttpClient]$HttpClient
    )

    try {
        return $HttpClient.GetStringAsync($Uri).GetAwaiter().GetResult()
    }
    catch {
        Write-Warning "Failed to retrieve $Uri : $($_.Exception.Message)"
        return $null
    }
}

function Get-EmailCandidates {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$HtmlContent
    )

    $pattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}"
    $matches = [regex]::Matches($HtmlContent, $pattern)
    $emails = $matches | ForEach-Object { $_.Value -replace '^mailto:', '' }
    $emails = $emails | Where-Object { $_ -notmatch 'example\\.com' -and $_ -notmatch 'test@' }
    return $emails | Select-Object -Unique
}

function Get-ContactPageUrls {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Html,
        [Parameter(Mandatory)][Uri]$BaseUri
    )

    $contactLinks = @()
    try {
        $pattern = '<a\s+(?:[^>]*?\s+)?href=(?:''|"")([^''""]+)(?:''|"")'
        $matches = [regex]::Matches($Html, $pattern, 'IgnoreCase')
        foreach ($m in $matches) {
            $href = $m.Groups[1].Value
            if ($href -match 'contact') {
                try {
                    $linkUri = [Uri]::new($href, [UriKind]::RelativeOrAbsolute)
                    if (-not $linkUri.IsAbsoluteUri) {
                        $linkUri = [Uri]::new($BaseUri, $linkUri)
                    }
                    if ($contactLinks -notcontains $linkUri) {
                        $contactLinks += $linkUri
                    }
                }
                catch {
                    continue
                }
            }
        }
    }
    catch {
    }
    return $contactLinks
}

function Resolve-ContactEmail {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][System.Collections.IEnumerable]$Candidates,
        [string]$PreferredDomain
    )

    if (-not $Candidates) { return $null }
    $unique = New-Object System.Collections.Generic.List[string]
    foreach ($item in $Candidates) {
        if ([string]::IsNullOrWhiteSpace($item)) { continue }
        $unique.Add($item.ToLower())
    }
    $unique = $unique | Select-Object -Unique

    if ($unique.Count -eq 0) { return $null }

    if ($PreferredDomain) {
        foreach ($email in $unique) {
            if ($email -like "*$PreferredDomain") { return $email }
        }
    }
    return $unique[0]
}

function Resolve-OwnerNameFromHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Html,
        [string]$BusinessName
    )

    $ownerRegex = [regex]"(Founder|CEO|Owner|Managing Director|Director)\\W{1,20}([A-Z][a-z]+\\s+[A-Z][a-z]+)"
    $match = $ownerRegex.Match($Html)
    if ($match.Success) {
        return $match.Groups[2].Value
    }

    if ($BusinessName) {
        $nameRegex = [regex]::new([regex]::Escape($BusinessName) + '.*?([A-Z][a-z]+\\s+[A-Z][a-z]+)', 'Singleline')
        $alt = $nameRegex.Match($Html)
        if ($alt.Success) {
            return $alt.Groups[1].Value
        }
    }
    return $null
}

function Build-LeadAnalysisPrompt {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$BusinessName,
        [string]$Service,
        [string]$Location,
        [string]$Website,
        [string]$RatingSummary,
        [string]$ExistingPain,
        [string]$Context
    )

    $websiteLine = if ($Website) { "Website: $Website" } else { '' }
    $ratingLine  = if ($RatingSummary) { "Rating: $RatingSummary" } else { '' }
    $painLine    = if ($ExistingPain) { "Existing Info: $ExistingPain" } else { '' }
    $contextLine = if ($Context) { "Context: $Context" } else { '' }

    @"
You are an experienced B2B marketing analyst.

Business: $BusinessName
Location: $Location
$websiteLine
$ratingLine
$painLine
$contextLine

The service we offer is: $Service.

Provide:
1. Two bullet points about how the business could benefit from this service.
2. One likely pain point that our service can solve for them.
3. A likelihood score (1-10) with a short justification for how much they need this service.

Respond exactly in this format:
Key Points: - point one; - point two
Pain Point: description
Likelihood: X/10 - justification
"@
}

function Invoke-LeadAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$BusinessName,
        [string]$Service,
        [string]$Location,
        [string]$Website,
        [string]$RatingSummary,
        [string]$Observation,
        [string]$Context,
        [string]$OpenAIApiKey,
        [string]$Model = 'gpt-3.5-turbo',
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    if ([string]::IsNullOrWhiteSpace($OpenAIApiKey)) {
        return [PSCustomObject]@{ KeyPoints=''; PainPoint=''; Likelihood='' }
    }

    $prompt = Build-LeadAnalysisPrompt -BusinessName $BusinessName -Service $Service -Location $Location -Website $Website -RatingSummary $RatingSummary -ExistingPain $Observation -Context $Context
    $body = @{ model = $Model; messages = @(@{ role = 'user'; content = $prompt }); temperature = 0.6 }
    $jsonBody = $body | ConvertTo-Json -Depth 4
    $headers = @{ Authorization = "Bearer $OpenAIApiKey"; 'Content-Type' = 'application/json' }

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $response = Invoke-RestMethod -Uri 'https://api.openai.com/v1/chat/completions' -Method Post -Headers $headers -Body $jsonBody -ErrorAction Stop
            $content = $response.choices[0].message.content
            if (-not $content) { throw 'AI response was empty' }

            $keyPoints = ''
            $painPoint = ''
            $likelihood = ''
            if ($content -match 'Key Points:\s*(.+?)\s*Pain Point:\s*(.+?)\s*Likelihood:\s*(.+)') {
                $keyPoints  = ($Matches[1] -replace '\s*\n\s*', ' ').Trim()
                $painPoint  = $Matches[2].Trim()
                $likelihood = $Matches[3].Trim()
            }
            else {
                $keyPoints = $content.Trim()
            }

            return [PSCustomObject]@{
                KeyPoints  = $keyPoints
                PainPoint  = $painPoint
                Likelihood = $likelihood
            }
        }
        catch {
            Write-Warning ("OpenAI call for '{0}' failed on attempt {1}: {2}" -f $BusinessName, $attempt, $_)
            if ($attempt -eq $MaxAttempts) { break }
            Start-Sleep -Seconds ([math]::Min($DelaySeconds * $attempt, 10))
        }
    }

    [PSCustomObject]@{ KeyPoints=''; PainPoint=''; Likelihood='' }
}

function Invoke-LeadScraper {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Location,
        [double]$RadiusMiles = 5,
        [Parameter(Mandatory)][string]$Service,
        [string]$Keyword,
        [string]$Type,
        [string]$OutputDirectory = (Get-Location).Path,
        [ValidateSet('csv','json')][string]$OutputFormat = 'csv',
        [string]$GoogleApiKey = $env:GOOGLE_MAPS_API_KEY,
        [string]$OpenAIApiKey = $env:OPENAI_API_KEY,
        [string]$OpenAIModel = 'gpt-3.5-turbo',
        [switch]$SkipAI,
        [switch]$ShowMap,
        [int]$OpenAIDelayMilliseconds = 1200,
        [hashtable]$TestOverrides
    )

    if (-not $GoogleApiKey) {
        throw 'Google Maps API key is required. Set the GOOGLE_MAPS_API_KEY environment variable or supply -GoogleApiKey.'
    }

    if (-not (Test-Path -Path $OutputDirectory)) {
        New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    }

    $geocode = if ($TestOverrides && $TestOverrides.ContainsKey('Get-Geocode')) {
        & $TestOverrides['Get-Geocode'] $Location $GoogleApiKey
    }
    else {
        Get-Geocode -Location $Location -ApiKey $GoogleApiKey
    }

    $radiusMeters = [int](ConvertTo-Meters -Value $RadiusMiles -Unit 'mile')
    $radiusMeters = [math]::Min($radiusMeters, 50000)

    $places = if ($TestOverrides && $TestOverrides.ContainsKey('Get-PlacesNearby')) {
        & $TestOverrides['Get-PlacesNearby'] $geocode.Latitude $geocode.Longitude $radiusMeters $GoogleApiKey $Keyword $Type
    }
    else {
        Get-PlacesNearby -Latitude $geocode.Latitude -Longitude $geocode.Longitude -RadiusMeters $radiusMeters -ApiKey $GoogleApiKey -Keyword $Keyword -Type $Type
    }
    $places = @($places)
    if (-not $places -or $places.Count -eq 0) {
        Write-Warning 'No businesses were found for the specified criteria.'
        return [PSCustomObject]@{
            Leads      = @()
            OutputPath = $null
            MapPath    = $null
        }
    }

    Add-Type -AssemblyName System.Net.Http
    $handler = [System.Net.Http.HttpClientHandler]::new()
    $handler.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate -bor [System.Net.DecompressionMethods]::Brotli
    $httpClient = [System.Net.Http.HttpClient]::new($handler)
    $httpClient.Timeout = [TimeSpan]::FromSeconds(20)
    $httpClient.DefaultRequestHeaders.UserAgent.ParseAdd('LeadScraperBot/1.1')
    $httpClient.DefaultRequestHeaders.AcceptEncoding.ParseAdd('gzip, deflate, br')

    $leads = New-Object System.Collections.Generic.List[object]
    $suppressProgress = $TestOverrides && $TestOverrides.ContainsKey('DisableProgress')

    try {
        $counter = 0
        foreach ($place in $places) {
            $counter++
            if (-not $suppressProgress) {
                Write-Progress -Activity 'Retrieving place details' -Status $place.name -PercentComplete (($counter / $places.Count) * 100)
            }
            try {
                $details = if ($TestOverrides && $TestOverrides.ContainsKey('Get-PlaceDetails')) {
                    & $TestOverrides['Get-PlaceDetails'] $place.place_id $GoogleApiKey
                }
                else {
                    Get-PlaceDetails -PlaceId $place.place_id -ApiKey $GoogleApiKey
                }
            }
            catch {
                Write-Warning "Skipping place $($place.name) due to details error: $_"
                continue
            }

            $websiteUri = Get-NormalizedUri -Url $details.website
            $html = $null
            $contactEmail = $null
            $ownerName = $null
            $observation = ''

            $contactPages = @()
            if ($websiteUri) {
                $html = if ($TestOverrides && $TestOverrides.ContainsKey('Get-WebsiteContent')) {
                    & $TestOverrides['Get-WebsiteContent'] $websiteUri $httpClient
                }
                else {
                    Get-WebsiteContent -Uri $websiteUri -HttpClient $httpClient
                }
                $emails = @()
                if ($html) {
                    $emails = if ($TestOverrides && $TestOverrides.ContainsKey('Get-EmailCandidates')) {
                        & $TestOverrides['Get-EmailCandidates'] $html
                    }
                    else {
                        Get-EmailCandidates -HtmlContent $html
                    }
                    $emails = @($emails)
                    $emailCount = ($emails | Measure-Object).Count
                    if ($emailCount -eq 0) {
                        $contactPages = Get-ContactPageUrls -Html $html -BaseUri $websiteUri
                        foreach ($contactUri in $contactPages) {
                            $contactHtml = if ($TestOverrides && $TestOverrides.ContainsKey('Get-WebsiteContent')) {
                                & $TestOverrides['Get-WebsiteContent'] $contactUri $httpClient
                            }
                            else {
                                Get-WebsiteContent -Uri $contactUri -HttpClient $httpClient
                            }
                            if ($contactHtml) {
                                $moreEmails = if ($TestOverrides && $TestOverrides.ContainsKey('Get-EmailCandidates')) {
                                    & $TestOverrides['Get-EmailCandidates'] $contactHtml
                                }
                                else {
                                    Get-EmailCandidates -HtmlContent $contactHtml
                                }
                                $emails += @($moreEmails)
                                $emailCount = ($emails | Measure-Object).Count
                                if ($emailCount -gt 0) { break }
                            }
                        }
                    }

                    $preferredDomain = if ($websiteUri.Host) { '@' + $websiteUri.Host.TrimStart('www.') } else { $null }
                    $contactEmail = Resolve-ContactEmail -Candidates $emails -PreferredDomain $preferredDomain
                    $ownerName = if ($TestOverrides && $TestOverrides.ContainsKey('Resolve-OwnerNameFromHtml')) {
                        & $TestOverrides['Resolve-OwnerNameFromHtml'] $html $details.name
                    }
                    else {
                        Resolve-OwnerNameFromHtml -Html $html -BusinessName $details.name
                    }
                    if (-not $ownerName -and $contactPages) {
                        foreach ($contactUri in $contactPages) {
                            $contactHtml = if ($TestOverrides && $TestOverrides.ContainsKey('Get-WebsiteContent')) {
                                & $TestOverrides['Get-WebsiteContent'] $contactUri $httpClient
                            }
                            else {
                                Get-WebsiteContent -Uri $contactUri -HttpClient $httpClient
                            }
                            if ($contactHtml) {
                                $ownerName = if ($TestOverrides && $TestOverrides.ContainsKey('Resolve-OwnerNameFromHtml')) {
                                    & $TestOverrides['Resolve-OwnerNameFromHtml'] $contactHtml $details.name
                                }
                                else {
                                    Resolve-OwnerNameFromHtml -Html $contactHtml -BusinessName $details.name
                                }
                                if ($ownerName) { break }
                            }
                        }
                    }
                }
            }
            else {
                $observation = 'No official website found.'
            }

            if ($websiteUri -and -not $contactEmail) {
                $observation = 'No contact email found on the website.'
            }

            $ratingSummary = $null
            if ($details.rating) {
                $ratingSummary = "{0}/5 from {1} reviews" -f $details.rating, $details.user_ratings_total
            }

            $aiResult = [PSCustomObject]@{ KeyPoints=''; PainPoint=''; Likelihood='' }
            if (-not $SkipAI.IsPresent) {
                $aiResult = if ($TestOverrides && $TestOverrides.ContainsKey('Invoke-LeadAnalysis')) {
                    & $TestOverrides['Invoke-LeadAnalysis'] $details.name $Service $geocode.FormattedAddress $details.website $ratingSummary $observation $ownerName $OpenAIApiKey $OpenAIModel
                }
                else {
                    Invoke-LeadAnalysis -BusinessName $details.name -Service $Service -Location $geocode.FormattedAddress -Website $details.website -RatingSummary $ratingSummary -Observation $observation -Context $ownerName -OpenAIApiKey $OpenAIApiKey -Model $OpenAIModel
                }
                if (-not $aiResult) { $aiResult = [PSCustomObject]@{ KeyPoints=''; PainPoint=''; Likelihood='' } }
                if ($OpenAIDelayMilliseconds -gt 0 -and $OpenAIApiKey) {
                    Start-Sleep -Milliseconds $OpenAIDelayMilliseconds
                }
            }

            $postalCode = $null
            foreach ($component in $details.address_components) {
                if ($component.types -contains 'postal_code') {
                    $postalCode = $component.long_name
                    break
                }
            }

            $lead = [PSCustomObject]@{
                Name       = $details.name
                Address    = $details.formatted_address
                Postcode   = $postalCode
                Phone      = $details.international_phone_number
                Email      = $contactEmail
                Owner      = $ownerName
                Website    = $details.website
                Rating     = $ratingSummary
                Latitude   = if ($details.geometry.location.lat) { [double]$details.geometry.location.lat } else { $null }
                Longitude  = if ($details.geometry.location.lng) { [double]$details.geometry.location.lng } else { $null }
                KeyPoints  = $aiResult.KeyPoints
                PainPoint  = $aiResult.PainPoint
                Likelihood = $aiResult.Likelihood
                GoogleUrl  = $details.url
            }

            $leads.Add($lead)
        }
    }
    finally {
        $httpClient.Dispose()
        if (-not $suppressProgress) {
            Write-Progress -Activity 'Retrieving place details' -Completed
        }
    }

    $fileName = New-LeadOutputFileName -Location $Location -RadiusMiles $RadiusMiles -Service $Service -Format $OutputFormat
    $filePath = Join-Path -Path $OutputDirectory -ChildPath $fileName
    switch ($OutputFormat) {
        'json' { $leads | ConvertTo-Json -Depth 4 | Set-Content -Path $filePath -Encoding UTF8 }
        default { $leads | Export-Csv -Path $filePath -NoTypeInformation -Encoding UTF8 }
    }

    Write-Host "Saved lead data to $filePath" -ForegroundColor Green

    $mapPath = $null
    $mapRequested = $PSBoundParameters.ContainsKey('ShowMap') -or ($ShowMap -is [bool] -and $ShowMap) -or ($ShowMap -is [System.Management.Automation.SwitchParameter] -and $ShowMap.IsPresent)
    if ($mapRequested) {
        try {
            $mapPath = if ($TestOverrides && $TestOverrides.ContainsKey('New-LeadMap')) {
                & $TestOverrides['New-LeadMap'] $leads.ToArray() $geocode.Latitude $geocode.Longitude $radiusMeters $GoogleApiKey $OutputDirectory
            }
            else {
                New-LeadMap -Leads $leads.ToArray() -Latitude $geocode.Latitude -Longitude $geocode.Longitude -RadiusMeters $radiusMeters -GoogleApiKey $GoogleApiKey -OutputDirectory $OutputDirectory
            }
            if ($mapPath) {
                Write-Host "Opening lead map: $mapPath" -ForegroundColor Green
                if ($TestOverrides && $TestOverrides.ContainsKey('Invoke-Item')) {
                    & $TestOverrides['Invoke-Item'] $mapPath
                }
                else {
                    Invoke-Item $mapPath
                }
            }
        }
        catch {
            Write-Warning "Map generation failed: $($_.Exception.Message)"
        }
    }

    return [PSCustomObject]@{
        Leads      = $leads.ToArray()
        OutputPath = $filePath
        MapPath    = $mapPath
    }
}

function New-LeadMap {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][System.Collections.IEnumerable]$Leads,
        [Parameter(Mandatory)][double]$Latitude,
        [Parameter(Mandatory)][double]$Longitude,
        [Parameter(Mandatory)][int]$RadiusMeters,
        [Parameter(Mandatory)][string]$GoogleApiKey,
        [Parameter()][string]$OutputDirectory = (Get-Location).Path
    )

    if (-not (Test-Path -Path $OutputDirectory)) {
        New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    }

    $zoom = if ($RadiusMeters -le 1000) { 14 } elseif ($RadiusMeters -le 5000) { 13 } elseif ($RadiusMeters -le 20000) { 12 } else { 11 }

    $markerBuilder = New-Object System.Text.StringBuilder
    foreach ($lead in $Leads) {
        if ($lead.Latitude -and $lead.Longitude) {
            $nameEscaped = ($lead.Name -replace "'", "\'")
            [void]$markerBuilder.AppendLine("new google.maps.Marker({ position: {lat: $($lead.Latitude), lng: $($lead.Longitude)}, map: map, title: '$nameEscaped' });")
        }
    }

    $html = @"
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Lead Map</title>
  <style> html, body, #map { width: 100%; height: 100%; margin: 0; padding: 0; } </style>
  <script src="https://maps.googleapis.com/maps/api/js?key=$GoogleApiKey"></script>
  <script>
    function initMap() {
      var center = { lat: $Latitude, lng: $Longitude };
      var map = new google.maps.Map(document.getElementById('map'), {
        zoom: $zoom,
        center: center
      });
      new google.maps.Circle({
        center: center,
        radius: $RadiusMeters,
        strokeColor: '#007ACC',
        strokeOpacity: 0.5,
        strokeWeight: 2,
        fillColor: '#007ACC',
        fillOpacity: 0.1,
        map: map
      });
      $($markerBuilder.ToString())
    }
  </script>
</head>
<body onload="initMap()">
  <div id="map"></div>
</body>
</html>
"@

    $fileName = 'lead_map_{0}.html' -f (Get-Date -Format 'yyyyMMdd_HHmmss')
    $filePath = Join-Path -Path $OutputDirectory -ChildPath $fileName
    Set-Content -Path $filePath -Value $html -Encoding UTF8
    return $filePath
}

Export-ModuleMember -Function Invoke-LeadScraper, New-LeadMap, New-LeadOutputFileName, ConvertTo-Meters, Normalize-FileNameComponent, Build-LeadAnalysisPrompt, Resolve-ContactEmail, Get-EmailCandidates, Get-Geocode, Get-PlacesNearby, Get-PlaceDetails, Get-WebsiteContent, Resolve-OwnerNameFromHtml, Invoke-LeadAnalysis
