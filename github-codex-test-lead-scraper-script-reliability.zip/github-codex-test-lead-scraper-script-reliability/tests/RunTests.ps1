param([switch]$CI)

$ErrorActionPreference = 'Stop'

$modulePath = Join-Path (Split-Path $PSScriptRoot -Parent) 'src' 'LeadScraper.psd1'
Import-Module $modulePath -Force

$artifactsPath = Join-Path $PSScriptRoot 'artifacts'
if (Test-Path $artifactsPath) {
    Remove-Item $artifactsPath -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $artifactsPath -Force | Out-Null

$failures = New-Object System.Collections.Generic.List[object]

function Assert-True {
    param(
        [Parameter(Mandatory)][bool]$Condition,
        [Parameter(Mandatory)][string]$Message
    )
    if (-not $Condition) { throw $Message }
}

function Assert-Equal {
    param(
        [Parameter(Mandatory)]$Actual,
        [Parameter(Mandatory)]$Expected,
        [Parameter(Mandatory)][string]$Message
    )
    if ($Actual -ne $Expected) {
        throw "${Message} (expected: $Expected, actual: $Actual)"
    }
}

function Assert-Match {
    param(
        [Parameter(Mandatory)][string]$Actual,
        [Parameter(Mandatory)][string]$Pattern,
        [Parameter(Mandatory)][string]$Message
    )
    if ($Actual -notmatch $Pattern) {
        throw "${Message}`nActual: $Actual`nPattern: $Pattern"
    }
}

function Assert-Contains {
    param(
        [Parameter(Mandatory)]$Collection,
        [Parameter(Mandatory)]$Item,
        [Parameter(Mandatory)][string]$Message
    )
    if (-not ($Collection -contains $Item)) {
        throw "${Message}`nExpected to contain: $Item"
    }
}

function Assert-FileExists {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Message
    )
    if (-not (Test-Path $Path)) {
        throw "${Message}`nMissing: $Path"
    }
}

function Invoke-Test {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][ScriptBlock]$Body
    )

    Write-Host "Running $Name..." -ForegroundColor Cyan
    try {
        & $Body
        Write-Host "✔ $Name" -ForegroundColor Green
    }
    catch {
        $failures.Add([PSCustomObject]@{ Name = $Name; Error = $_.Exception.Message }) | Out-Null
        Write-Host "✘ $Name" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor DarkRed
    }
}

Invoke-Test 'ConvertTo-Meters converts miles to meters' {
    $meters = LeadScraper\ConvertTo-Meters -Value 1 -Unit 'mile'
    Assert-Equal -Actual $meters -Expected 1609.34 -Message 'Mile conversion should equal 1609.34 meters'
}

Invoke-Test 'Output file names are sanitized' {
    $fileName = LeadScraper\New-LeadOutputFileName -Location 'New York, NY' -RadiusMiles 5 -Service 'SEO Consulting' -Format 'csv'
    Assert-Match -Actual $fileName -Pattern '^leads_New_York_NY_5mi_SEO_Consulting_\d{8}_\d{6}\.csv$' -Message 'Filename should follow naming convention'
}

Invoke-Test 'Prompt builder includes required sections' {
    $prompt = LeadScraper\Build-LeadAnalysisPrompt -BusinessName 'Sample Biz' -Service 'SEO' -Location 'Austin, TX' -Website 'https://example.com' -RatingSummary '4.5/5 from 12 reviews' -ExistingPain 'No contact email' -Context 'John Doe'
    Assert-Match -Actual $prompt -Pattern 'Business: Sample Biz' -Message 'Prompt should include business name'
    Assert-Match -Actual $prompt -Pattern 'Key Points:' -Message 'Prompt should request key points'
    Assert-Match -Actual $prompt -Pattern 'Likelihood:' -Message 'Prompt should request likelihood'
}

Invoke-Test 'Email extraction finds addresses in html' {
    $html = '<html><body>Contact us at <a href="mailto:sales@example.org">sales@example.org</a> or info@example.org</body></html>'
    $emails = LeadScraper\Get-EmailCandidates -HtmlContent $html
    Assert-Contains -Collection $emails -Item 'sales@example.org' -Message 'Should include sales@example.org'
    Assert-Contains -Collection $emails -Item 'info@example.org' -Message 'Should include info@example.org'
}

Invoke-Test 'Resolve-ContactEmail prefers company domain' {
    $candidates = @('contact@gmail.com', 'hello@company.com')
    $selected = LeadScraper\Resolve-ContactEmail -Candidates $candidates -PreferredDomain '@company.com'
    Assert-Equal -Actual $selected -Expected 'hello@company.com' -Message 'Should prefer matching company domain'
}

Invoke-Test 'Invoke-LeadScraper returns empty result when no places are found' {
    $overrides = @{
        'Get-Geocode'       = { param([string]$Location, [string]$ApiKey) [PSCustomObject]@{ Latitude = 0; Longitude = 0; FormattedAddress = 'Nowhere' } }
        'Get-PlacesNearby'  = { param($Latitude, $Longitude, $RadiusMeters, $ApiKey, $Keyword, $Type) @() }
        'DisableProgress'   = $true
    }

    $result = LeadScraper\Invoke-LeadScraper -Location 'Empty' -Service 'Testing' -GoogleApiKey 'dummy' -OutputDirectory $artifactsPath -TestOverrides $overrides
    Assert-True -Condition ($result.Leads.Count -eq 0) -Message 'Should return zero leads when none found'
    Assert-True -Condition ([string]::IsNullOrEmpty($result.OutputPath)) -Message 'OutputPath should be empty when no leads are saved'
    Assert-True -Condition ([string]::IsNullOrEmpty($result.MapPath)) -Message 'MapPath should be empty when map is not generated'
}

Invoke-Test 'Invoke-LeadScraper produces output and map when data is available' {
    $overrides = @{
        'Get-Geocode'              = { param([string]$Location, [string]$ApiKey) [PSCustomObject]@{ Latitude = 10; Longitude = 20; FormattedAddress = 'Test City' } }
        'Get-PlacesNearby'         = { param($Latitude, $Longitude, $RadiusMeters, $ApiKey, $Keyword, $Type) @(@{ place_id = '1'; name = 'Alpha' }) }
        'Get-PlaceDetails'         = { param([string]$PlaceId, [string]$ApiKey)
            [PSCustomObject]@{
                name = 'Alpha'
                formatted_address = '123 Road'
                international_phone_number = '+1 555 0100'
                website = 'https://alpha.test'
                rating = 4.5
                user_ratings_total = 10
                geometry = @{ location = @{ lat = 10.1; lng = 20.1 } }
                address_components = @()
                url = 'https://maps.example/alpha'
            }
        }
        'Get-WebsiteContent'       = { param([Uri]$Uri, [System.Net.Http.HttpClient]$HttpClient) $null }
        'Invoke-LeadAnalysis'      = { param($BusinessName, $Service, $Location, $Website, $RatingSummary, $Observation, $Context, $ApiKey, $Model) [PSCustomObject]@{ KeyPoints = 'Key Points'; PainPoint = 'Pain'; Likelihood = '7/10' } }
        'New-LeadMap'              = { param($Leads, $Latitude, $Longitude, $RadiusMeters, $GoogleApiKey, $OutputDirectory)
            $file = Join-Path $OutputDirectory 'mock_map.html'
            Set-Content -Path $file -Value '<html></html>' -Encoding UTF8
            $file
        }
        'Invoke-Item'              = { param($Path) }
        'DisableProgress'          = $true
    }

    $result = LeadScraper\Invoke-LeadScraper -Location 'Alpha City' -Service 'Testing' -GoogleApiKey 'dummy' -OutputDirectory $artifactsPath -ShowMap -SkipAI -TestOverrides $overrides

    Assert-Equal -Actual $result.Leads.Count -Expected 1 -Message 'Should return one mocked lead'
    Assert-FileExists -Path $result.OutputPath -Message 'Output file should be created'
    Assert-FileExists -Path $result.MapPath -Message 'Map file should be created'
}

if ($failures.Count -gt 0) {
    Write-Host ''
    Write-Host 'Test failures:' -ForegroundColor Red
    foreach ($failure in $failures) {
        Write-Host "- $($failure.Name): $($failure.Error)" -ForegroundColor Red
    }
    throw "${($failures.Count)} test(s) failed."
}
else {
    Write-Host ''
    Write-Host 'All tests passed.' -ForegroundColor Green
}
